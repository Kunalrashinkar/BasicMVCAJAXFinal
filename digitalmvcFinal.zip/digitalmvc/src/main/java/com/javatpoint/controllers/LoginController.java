package com.javatpoint.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.tomcat.util.http.Cookies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Login;
import com.javatpoint.beans.User;
import com.javatpoint.service.UserService;

@Controller

public class LoginController {
	@Autowired
	UserService userService;
	
	@RequestMapping(value="login", method=RequestMethod.GET)
	public ModelAndView  showLogin(@ModelAttribute("login") Login login ,HttpServletRequest request, HttpServletResponse response)
	{
		/*Cookie[] cookies = request.getCookies();
		
		for(Cookie temp: cookies)
		{
			if("username".equals(temp.getName())){
				String myUserName=temp.getValue();
				login.setUsername(myUserName);
			}
		}*/
		ModelAndView mav = new ModelAndView("login");
		
		
		
		mav.addObject("login", new Login());
		
		return mav;
	}
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView loginProcess(@Valid  @ModelAttribute("login") Login login, 
			HttpSession session,HttpServletRequest request,HttpServletResponse response){
		//ModelAndView mav=null;
		ModelAndView mav =new ModelAndView("login");;
		
		/*Login loginpojo = new Login();
		System.out.println("==========="+login);
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println("==========="+username);
		loginpojo.setPassword(password);
		loginpojo.setUsername(username);		
		*/
		

   	
		
		
      
        User user= userService.validateUser(login);
		
		if(user != null)
		{
			String username = request.getParameter("username");
			
	        session= request.getSession();
	        session.setAttribute("user", username);
			
			mav= new ModelAndView("redirect:/viewemp");
		    mav.addObject("firstname", user.getFirstname());
		    mav.addObject("userID", user.getUserid());
		    
		    return mav;
		}
		else
		{
			mav= new ModelAndView("login");
			mav.addObject("message", "Username and Password is incorrect !!");
			return mav;
		}
		
		
		/*Cookie ck= new Cookie("username", login.getUsername());
		ck.setMaxAge(60*60*24);
		
		response.addCookie(ck);
		*/
		//session= request.getSession();
		//session.setAttribute("username", login.getUsername());
		//session.setMaxInactiveInterval(120);
		
		
	}
	@RequestMapping(value="logout", method= RequestMethod.GET)
	public String logout(HttpServletRequest request)
	{
        HttpSession session=request.getSession(false);
		
		System.out.println("User="+session.getAttribute("user"));
		
		if(session!=null)
		{
			session.invalidate();
		}
		
		return "redirect:../digitalmvc";
	}

}
