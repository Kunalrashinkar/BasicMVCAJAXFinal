package com.javatpoint.controllers;

import java.io.IOException;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Emp;
import com.javatpoint.beans.Login;
import com.javatpoint.dao.EmpDao;


@Controller
public class EmpController {
 
	 @Autowired    
	    EmpDao dao;
	 

	 
	 @RequestMapping(value="/empform", method=RequestMethod.GET)    
	    public String showform(Model m,HttpServletRequest request ){  
		 HttpSession session=request.getSession(false);

         if( session.getAttribute("user")==null){
      	   return "redirect:/login";
         }
	        m.addAttribute("command", new Emp());  
	        return "empform";
	        } 
	 
	 
	 @RequestMapping(value="/save",method = RequestMethod.POST)    
	    public String save(@ModelAttribute("emp") Emp emp,HttpServletRequest request){
		 Login login = new Login();
		 String name = request.getParameter("name");
		 		 login.setUsername(name);
		String sal= request.getParameter("salary");
		String desig=request.getParameter("designation");
		
		 if(name==null || name.length()==0){
			 System.out.println("name is not null");
			 return "redirect:/viewemp";
		 }
		 else if(sal.isEmpty())
		 {
			 System.out.println("Salary is not null");
			 return "redirect:/viewemp";
			 
		 }
		 else if (desig==null || desig.length()==0)
		 {
			 System.out.println("Designation is not null"); 
			 return "redirect:/viewemp";
		 }
		 
		 else{
			 dao.save(emp);  
			 return "redirect:/viewemp";
		 }
	 }
	 
	 /*@RequestMapping(value="/viewemp", method= RequestMethod.GET)    
	    //public String viewemp(Model m){ 
	 public ModelAndView viewemp(ModelAndView mav,HttpServletRequest request,  HttpSession session) throws IOException{
		 Login loginp = new Login();
		 String username = request.getParameter("username");
			String password = request.getParameter("password");
		 loginp.setUsername(username);
		 loginp.setPassword(password);
		 
	
		 
		 
		 
		 String obj= (String) session.getAttribute("user");
		 System.out.println(obj + " = "+loginp.getUsername());
		 if(obj.equals(loginp.getUsername())){
		
			 
			 List<Emp> list=dao.getEmployees();
			 System.out.println(list);
		        mav.addObject("list", list);
		        
		        mav.setViewName("viewemp");
		        return mav;
		 }
		 else{
			 mav.setViewName("login");
			 return mav;
		 }
		 
	          
	    } */ 
	 @RequestMapping("/viewemp")    
	    public String viewemp(Model m,HttpServletRequest request){  
		 HttpSession session=request.getSession(false);

         if( session.getAttribute("user")==null){
      	   return "redirect:/login";
         }
		
	        List<Emp> list=dao.getEmployees();    
	        m.addAttribute("list",list);  
	        return "js";    
	    } 
	 
	 @RequestMapping(value="/editemp/{id}")    
	    public String edit(@PathVariable("id") int id, Model m,HttpServletRequest request,HttpServletResponse response){ 
		 
		 
     HttpSession session=request.getSession(false);
		 
		/* String username = null;
		 if(session.getAttribute("user") == null){
		 	return "login";
		 }
		 else {
			 username = (String) session.getAttribute("user");
		 }*/
     
           if( session.getAttribute("user")==null){
        	   return "redirect:/login";
           }
	        Emp emp=dao.getEmpById(id);    
	        m.addAttribute("command",emp);  
	        return "empeditform";    
	    }    
	 @RequestMapping(value="/editsave",method = RequestMethod.POST) 
	 public String editsave(@ModelAttribute("emp") Emp emp){  
		 
	     dao.update(emp);    
	        return "redirect:/viewemp";    
	    }    
	 @RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)    
	 public String delete(@PathVariable int id){    
	        dao.delete(id);    
	        return "redirect:/viewemp";    
	    }   
	 
}
